from django.http import JsonResponse
from django.shortcuts import render
# importamos los modelos para acceder a la base de datos
from CategoriasApp.models import Producto, Vendedor


# vista que muestra el listado completo de productos en JSON
def volumen(request):
    productos = list(Producto.objects.values('id', 'nombre', 'marca', 'precio', 'disponible'))
    return JsonResponse({'productos': productos})


# vista que renderiza el template pasando los datos
def catalogo(request):
    data = {
        'productos': Producto.objects.all(),
        'vendedores': Vendedor.objects.all(),
    }
    return render(request, 'CategoriasApp/catalogo.html', data)
