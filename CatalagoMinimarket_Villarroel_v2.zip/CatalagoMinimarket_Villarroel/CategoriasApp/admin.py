from django.contrib import admin
from CategoriasApp.models import Producto, Vendedor


class ProductoAdmin(admin.ModelAdmin):
    list_display = ['id', 'nombre', 'marca', 'precio', 'disponible', 'imagen']


class VendedorAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'apellidos']


# Register your models here.
admin.site.register(Producto, ProductoAdmin)
admin.site.register(Vendedor, VendedorAdmin)
