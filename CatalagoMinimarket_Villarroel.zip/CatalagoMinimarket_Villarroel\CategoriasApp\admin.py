from django.contrib import admin
from CategoriasApp.models import Producto


class ProductoAdmin(admin.ModelAdmin):
    list_display = ['id', 'nombre', 'marca', 'precio', 'disponible', 'imagen']


# Register your models here.
admin.site.register(Producto, ProductoAdmin)
