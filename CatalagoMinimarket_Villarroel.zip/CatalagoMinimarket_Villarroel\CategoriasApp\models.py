from django.db import models

# Create your models here.
class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    marca = models.CharField(max_length=50)
    precio = models.IntegerField()
    disponible = models.BooleanField(default=True)
    imagen = models.CharField(max_length=100, default='')

    def __str__(self):
        return self.nombre


class Vendedor(models.Model):
    nombre = models.CharField(max_length=50)
    apellidos = models.CharField(max_length=100)

    class Meta:
        verbose_name_plural = 'vendedores'

    def __str__(self):
        return self.nombre + ' ' + self.apellidos
