from django.contrib import admin
from django.urls import include, path


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('PrincipalApp.urls')),
    path('categorias/', include('CategoriasApp.urls')),
    path('negocio/', include('NegocioApp.urls')),
]