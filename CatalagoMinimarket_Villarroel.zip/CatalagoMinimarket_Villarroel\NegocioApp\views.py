from django.shortcuts import render


def negocio(request):
    data = {
        'nombre': 'Minimarket Villarroel',
        'telefono': '+56 9 1234 5678',
        'horario': 'Lunes a sabado de 09:00 a 21:00 hrs.',
    }
    return render(request, 'NegocioApp/negocio.html', data)
