from django.http import JsonResponse
from django.shortcuts import render
from CategoriasApp.models import Precios, Volumen


def _productos_catalogo():
    productos = []
    volumenes = Volumen.objects.select_related('precio_admin').order_by('id')
    for volumen in volumenes:
        try:
            precio = volumen.precio_admin.precio
            moneda = volumen.precio_admin.moneda
        except Precios.DoesNotExist:
            precio = None
            moneda = 'CLP'

        productos.append({
            'id': volumen.id,
            'nombre': volumen.nombre,
            'marca': volumen.marca,
            'categoria': volumen.categoria,
            'stock': volumen.stock,
            'imagen': volumen.imagen,
            'precio': int(precio) if precio is not None else None,
            'moneda': moneda,
            'disponible': volumen.disponible == 'Disponible',
        })
    return productos


def volumen(request):
    productos = [
        {key: producto[key] for key in ('id', 'nombre', 'marca', 'precio', 'disponible')}
        for producto in _productos_catalogo()
    ]
    return JsonResponse({'productos': productos})


# vista que renderiza el template pasando los datos
def catalogo(request):
    return render(request, 'CategoriasApp/catalogo.html', {'productos': _productos_catalogo()})
