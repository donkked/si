from django.contrib import admin
from CategoriasApp.models import Precios, Producto, Volumen


class ProductoAdmin(admin.ModelAdmin):
    list_display = ['id', 'nombre', 'marca', 'precio', 'disponible', 'imagen']
    search_fields = ['nombre', 'marca']
    list_filter = ['disponible']
    ordering = ['id']


admin.site.register(Producto, ProductoAdmin)

@admin.register(Volumen)
class VolumenAdmin(admin.ModelAdmin):
    list_display = ['id', 'nombre', 'categoria', 'marca', 'stock', 'disponible']
    search_fields = ['nombre', 'marca', 'categoria']
    list_filter = ['categoria', 'disponible']
    ordering = ['id']


@admin.register(Precios)
class PreciosAdmin(admin.ModelAdmin):
    list_display = ['id', 'volumen', 'precio', 'moneda', 'observacion']
    search_fields = ['volumen__nombre', 'observacion']
    list_filter = ['moneda']
    ordering = ['id']
