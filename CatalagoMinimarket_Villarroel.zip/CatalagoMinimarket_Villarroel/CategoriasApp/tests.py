from django.test import TestCase


class VolumenViewTests(TestCase):
	fixtures = ['productos.json']

	def test_volumen_returns_complete_product_catalog_as_json(self):
		response = self.client.get('/categorias/volumen/')

		self.assertEqual(response.status_code, 200)
		self.assertEqual(response['Content-Type'], 'application/json')
		self.assertEqual(len(response.json()['productos']), 20)
		self.assertEqual(
			set(response.json()['productos'][0]),
			{'id', 'nombre', 'marca', 'precio', 'disponible'},
		)

	def test_catalog_page_renders_products_without_admin_prices(self):
		response = self.client.get('/categorias/')

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Leche entera 1 L')
		self.assertContains(response, 'Por informar')
