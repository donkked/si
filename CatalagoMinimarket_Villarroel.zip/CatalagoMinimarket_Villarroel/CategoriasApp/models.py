from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

# Create your models here.
class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    marca = models.CharField(max_length=50)
    precio = models.IntegerField()
    disponible = models.BooleanField(default=True)
    imagen = models.CharField(max_length=100, default='')

    def __str__(self):
        return self.nombre


class Volumen(models.Model):
    id = models.PositiveSmallIntegerField(
        primary_key=True,
        validators=[MinValueValidator(1), MaxValueValidator(999)],
    )
    nombre = models.CharField(max_length=50)
    marca = models.CharField(max_length=50)
    disponible = models.CharField(max_length=20)
    categoria = models.CharField(max_length=50)
    stock = models.PositiveSmallIntegerField(default=0)
    imagen = models.CharField(max_length=100, blank=True, default='')

    class Meta:
        ordering = ('id',)

    def __str__(self):
        return self.nombre


class Precios(models.Model):
    volumen = models.OneToOneField(Volumen, on_delete=models.CASCADE, related_name='precio_admin')
    precio = models.DecimalField(max_digits=10, decimal_places=0)
    moneda = models.CharField(max_length=10, default='CLP')
    observacion = models.CharField(max_length=100, blank=True, default='')

    class Meta:
        ordering = ('id',)
        verbose_name_plural = 'precios'

    def __str__(self):
        return f'{self.volumen.nombre}: {self.precio} {self.moneda}'


class Vendedor(models.Model):
    nombre = models.CharField(max_length=50)
    apellidos = models.CharField(max_length=100)

    class Meta:
        verbose_name_plural = 'vendedores'

    def __str__(self):
        return self.nombre + ' ' + self.apellidos
